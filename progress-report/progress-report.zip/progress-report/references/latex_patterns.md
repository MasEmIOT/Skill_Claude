# LaTeX patterns for `progressreport.sty`

Contents: 1 macros · 2 tables · 3 figures · 4 timeline · 5 escaping · 6 compile errors · 7 layout fixes

## 1. Macros provided by the style

Metadata (in `meta.tex` only): `\reporttitle \reportproject \reportperiod
\reportauthor \reportrole \reportorganization \reportdepartment
\reportsupervisor \reportrecipient \reportversion \reportcode \reportdate
\reportlogo \reportlogoheight`. Empty values are dropped from the cover.

Body helpers:
- `\makereportcover` — cover page (logo, org, project, title, period, info block).
- `\stDone \stProgress \stPlanned \stBlocked \stNA` — coloured status words.
  Custom/translated: `\statustag{prDone}{Hoàn thành}`, `\statustag{prProgress}{Đang thực hiện}`,
  `\statustag{prPlanned}{Kế hoạch}`, `\statustag{prBlocked}{Bị chặn}`.
- `\evidence{commit 3f2a91c}` — small monospace source reference (verbatim-safe).
- `summarybox` environment — tinted box for the executive summary.
- Column types: `L` (wrapping X column), `P{3cm}` (wrapping fixed column).
- `\placeholder{...}` — red marker; `check_pdf.py` fails while any remain.
- `\ReportAuthor \ReportProject \ReportPeriod \ReportDate` — reuse in text.

## 2. Tables

Short table (fits one page):
```latex
\begin{table}[H]
\centering
\caption{Test results}\label{tab:tests}
\begin{tabularx}{\textwidth}{@{}L r r r@{}}
\toprule
\textbf{Suite} & \textbf{Tests} & \textbf{Passed} & \textbf{Failed} \\
\midrule
Unit        & 42 & 42 & 0 \\
Integration & 24 & 18 & 6 \\
\bottomrule
\end{tabularx}
\end{table}
```
Rules: booktabs only (no vertical lines), captions above tables, numbers
right-aligned, total width `\textwidth`, at most ~6 columns in portrait.

Long table (may break across pages) — use `longtable` with `P{}` columns that sum to < `\textwidth`:
```latex
\begin{longtable}{@{}P{5.2cm} P{2.3cm} P{6.6cm}@{}}
\caption{Completed tasks}\label{tab:done}\\
\toprule \textbf{Task} & \textbf{Status} & \textbf{Evidence}\\ \midrule
\endfirsthead
\toprule \textbf{Task} & \textbf{Status} & \textbf{Evidence}\\ \midrule
\endhead
\bottomrule
\endlastfoot
Relay driver & \stDone & \evidence{3f2a91c} \\
\end{longtable}
```
Use longtable when a table has more than ~15 rows.

## 3. Figures

```latex
\begin{figure}[H]
  \centering
  \includegraphics[width=0.85\textwidth,height=0.4\textheight,keepaspectratio]{arch.png}
  \caption{System architecture. Source: \texttt{docs/architecture.md}.}
  \label{fig:arch}
\end{figure}
```
Always `keepaspectratio` with both a width and height cap. Copy project images
into `figures/` (never reference paths outside the report folder). Screenshots:
`width=\textwidth`; photos/diagrams: 0.6–0.85. Side-by-side:
```latex
\begin{figure}[H]\centering
\begin{subfigure}{0.48\textwidth}\centering
  \includegraphics[width=\linewidth,keepaspectratio]{a.png}\caption{Before}\end{subfigure}\hfill
\begin{subfigure}{0.48\textwidth}\centering
  \includegraphics[width=\linewidth,keepaspectratio]{b.png}\caption{After}\end{subfigure}
\caption{UI change}\label{fig:ui}
\end{figure}
```
SVG images: convert first (`rsvg-convert -f pdf -o figures/x.pdf x.svg`).
Refer to every figure/table in the text: `Figure~\ref{fig:arch}`, `Table~\ref{tab:tests}`.

## 4. Timeline (only with real dates from the project)

```latex
\usepackage{pgfgantt}   % add in report.tex preamble only when used
\begin{ganttchart}[hgrid, vgrid, x unit=0.5cm, time slot format=isodate]{2026-09-01}{2026-10-31}
\gantttitlecalendar{month=name} \\
\ganttbar{Firmware}{2026-09-01}{2026-09-20} \\
\ganttbar{App}{2026-09-15}{2026-10-10}
\end{ganttchart}
```
Wrap in `\resizebox{\textwidth}{!}{...}` if wider than the text block.

## 5. Escaping

Text from project files must be escaped: `& % $ # _ { } ~ ^ \`.
`init_report.py` escapes metadata. In the body: file paths and hashes go in
`\evidence{...}` or `\texttt{\detokenize{...}}`; underscores in plain text as `\_`.
Long URLs/paths: `\url{...}` (breaks lines automatically).

## 6. Compile errors → fix

| Log message | Fix |
|---|---|
| `Undefined control sequence` | typo or macro from a package not loaded; check line number |
| `Missing $ inserted` | unescaped `_` or `^` in text |
| `Misplaced alignment tab character &` | unescaped `&` in text |
| `File 'x.png' not found` | copy it into `figures/`, check spelling/extension |
| `Missing character: There is no ệ in font` | using pdflatex without vntex → compile with xelatex |
| `Package fontspec Error` | font missing; remove the `\setmainfont` line or install tex-gyre |
| `Dimension too large` | image with huge DPI metadata → add explicit width |
| `Float(s) lost` | figure inside a table/minipage → move it out |
| `LaTeX Error: File 'xxx.sty' not found` | package missing: drop it if optional, or tell user to install (`tlmgr install xxx` / apt `texlive-latex-extra`) |

## 7. Layout fixes after visual inspection

- Table sticks out → switch to `tabularx` with `L`/`P{}` columns, shorten
  headers, `\small` inside the table, or landscape (`pdflscape`) for wide data.
- Figure orphaned on its own page with lots of white space → reduce height cap
  or use `[htbp]` instead of `[H]`.
- Heading at page bottom → `\needspace` is not loaded; add `\clearpage` before
  that section only if necessary.
- Cover logo too large/small → `\reportlogoheight{2cm}` in `meta.tex`.
- Long org/project names wrap badly on cover → shorten with the user's consent,
  or insert `\\` at a natural break.
