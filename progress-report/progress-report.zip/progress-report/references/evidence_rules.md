# Evidence rules and the evidence ledger

Every factual statement in the report must be traceable. The ledger at
`<report>/evidence/ledger.md` is the proof; it stays in the report folder and is
never rendered into the PDF.

## 1. What counts as evidence

| Kind | Examples | How to cite in ledger |
|---|---|---|
| Git | commit, tag, diffstat, commit count | `git log --since 2026-09-22 --oneline` / `commit a1b2c3d` |
| Test output | JUnit XML, pytest summary, CI log, a test you ran now | file path + counts, or exact command + date |
| Measurements | benchmark CSV/JSON, profiler output, serial logs | file path + column/row |
| Task state | `.claude/task-state/TASK-*/PROGRESS.md` entries tagged COMPLETED with `evidence:` | file path + item |
| Documents | README, design doc, previous report, meeting notes | file path + section |
| User statement | something the user said in this conversation | `user (chat, YYYY-MM-DD)` |

Not evidence: file names alone, TODO comments claiming something is done,
your own expectation of how long something takes, "typical" values.

## 2. Classify every claim

- **FACT** — directly from a source above. May contain numbers.
- **DERIVED** — computed from facts (e.g. 7 of 9 acceptance criteria ticked → 78%).
  Allowed; record the formula in the ledger.
- **ASSESSMENT** — your engineering judgement (risk, likely cause, recommendation).
  Allowed only when worded as assessment in the report: "The likely cause is…",
  "This is assessed as a schedule risk because…", "Proposed action: …".
- **UNKNOWN** — no source. Do not state it. Either omit, or write
  "Not measured yet" / "Not available" (EN) or "Chưa đo" / "Chưa có số liệu" (VI).

## 3. Numbers and percentages

- Progress % only when there is a countable denominator in the data
  (tasks in a tracker, checklist items, acceptance criteria, milestones with
  explicit done/not-done). Show the fraction next to it: `78\% (7/9 criteria)`.
- Never estimate % from "feel", commit volume, or elapsed time.
- Copy numbers exactly (units, decimals). Do not round in a way that changes meaning.
- If two sources disagree (e.g. task state says COMPLETED, test log shows FAIL),
  report the conservative status and mention the discrepancy in Issues.
  The repository/test output wins over state files.

## 4. Ledger format

```markdown
# Evidence ledger — <report folder name>

| Claim in report | Type | Source | Checked |
|---|---|---|---|
| 14 commits in period | FACT | `git log --since 2026-09-22 --until 2026-09-29` | 2026-09-29 |
| All 42 unit tests pass | FACT | `build/test-results/junit.xml` (tests=42 failures=0) | 2026-09-29 |
| Relay control module done | FACT | commit 3f2a91c; `.claude/task-state/TASK-.../PROGRESS.md` T-007 PASS | 2026-09-29 |
| Progress 78% | DERIVED | 7/9 acceptance criteria ticked in TASK.md | 2026-09-29 |
| MQTT broker latency is a risk | ASSESSMENT | based on F-002 in FAILED_ATTEMPTS.md | — |
```

`make_chart.py` appends figure rows automatically.

## 5. Progression against the previous report

When a previous report exists, build a commitment table before writing:

| Committed last period (Next Steps / In Progress) | Status now | Evidence |
|---|---|---|
| Implement OTA update | Completed | commit 9c1e… , test T-011 PASS |
| Write integration tests | In Progress | 3 of 6 test files exist in `tests/integration/` |
| Order PCB rev B | Not started | no evidence found → state "not started" |

Use it to (a) write a "Status of previous commitments" subsection inside
Progress Overview, (b) avoid silently dropping an item that was promised.
An item with no evidence either way is reported as "no update this period",
never as completed.

## 6. Missing inputs

- No git: say so in the ledger; use file mtimes and docs only.
- No tests: write "No automated test results available for this period."
  Do not invent a test section.
- No metrics at all: the Results section describes qualitative outcomes
  (feature X works as demonstrated in screenshot Y) and says metrics are not
  yet collected. That is acceptable and honest.
