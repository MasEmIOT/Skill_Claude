#!/usr/bin/env python3
"""Create a new progress-report folder from the skill template.

Never overwrites an existing report: if the target folder exists, a suffix
_v2, _v3 ... is appended. Only writes inside the reports directory.

Usage (from the project root):
  python3 init_report.py --project-root . --type weekly-progress \
      --title "Weekly Progress Report" --period "Week 4" \
      --author "Nguyen Van A" [--logo path] [--org ...] [--project ...] \
      [--supervisor ...] [--role ...] [--recipient ...] [--version 1.0] \
      [--lang en|vi] [--date YYYY-MM-DD] [--reports-dir reports]

Prints a JSON object with the created paths.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import shutil
import subprocess
import sys
import unicodedata
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATES = SKILL_DIR / "templates"
EXISTING_REPORT_DIRS = ["reports", "report", "Reports", "docs/reports",
                        "docs/report", "progress-reports", "bao-cao", "baocao"]
LATEX_SPECIALS = {
    "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
    "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
    "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
}


def tex_escape(text: str) -> str:
    return "".join(LATEX_SPECIALS.get(c, c) for c in text or "")


def slugify(text: str) -> str:
    text = text.replace("đ", "d").replace("Đ", "D")
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    text = re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()
    return text[:50] or "progress"


def find_reports_dir(root: Path, explicit: str | None) -> Path:
    if explicit:
        return (root / explicit).resolve()
    for cand in EXISTING_REPORT_DIRS:
        p = root / cand
        if p.is_dir():
            return p.resolve()
    return (root / "reports").resolve()


def unique_dir(base: Path) -> Path:
    if not base.exists():
        return base
    n = 2
    while True:
        cand = base.with_name(f"{base.name}_v{n}")
        if not cand.exists():
            return cand
        n += 1


def convert_svg(src: Path, dst_pdf: Path) -> bool:
    tools = [
        ["rsvg-convert", "-f", "pdf", "-o", str(dst_pdf), str(src)],
        ["inkscape", str(src), "--export-type=pdf", f"--export-filename={dst_pdf}"],
    ]
    for cmd in tools:
        if shutil.which(cmd[0]):
            if subprocess.run(cmd, capture_output=True).returncode == 0 and dst_pdf.exists():
                return True
    try:
        import cairosvg  # type: ignore
        cairosvg.svg2pdf(url=str(src), write_to=str(dst_pdf))
        return dst_pdf.exists()
    except Exception:
        return False


def copy_logo(logo: str, root: Path, assets: Path) -> tuple[str, str]:
    """Return (tex path relative to report dir, note)."""
    src = Path(logo).expanduser()
    if not src.is_absolute():
        src = (root / src).resolve()
    if not src.is_file():
        return "", f"logo not found: {src}"
    ext = src.suffix.lower()
    if ext in (".png", ".jpg", ".jpeg", ".pdf", ".eps"):
        dst = assets / f"logo{ext}"
        shutil.copy2(src, dst)
        return f"assets/{dst.name}", f"copied {src} -> {dst}"
    if ext == ".svg":
        dst = assets / "logo.pdf"
        shutil.copy2(src, assets / "logo_original.svg")
        if convert_svg(src, dst):
            return "assets/logo.pdf", f"converted SVG {src} -> {dst}"
        return "", ("SVG logo could not be converted (install rsvg-convert, "
                    "inkscape or cairosvg, or supply PNG/PDF). Report built without logo.")
    return "", f"unsupported logo format: {ext}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--reports-dir", default=None)
    ap.add_argument("--type", default="weekly-progress",
                    help="report type slug used in folder name, e.g. weekly-progress")
    ap.add_argument("--date", default=None, help="YYYY-MM-DD (default: today)")
    ap.add_argument("--folder-date", default=None,
                    help="override date prefix, e.g. 2026-10 for monthly reports")
    ap.add_argument("--title", default="Progress Report")
    ap.add_argument("--period", default="")
    ap.add_argument("--author", default="")
    ap.add_argument("--role", default="")
    ap.add_argument("--org", default="")
    ap.add_argument("--department", default="")
    ap.add_argument("--project", default="")
    ap.add_argument("--supervisor", default="")
    ap.add_argument("--recipient", default="")
    ap.add_argument("--version", default="")
    ap.add_argument("--doc-code", default="")
    ap.add_argument("--logo", default="")
    ap.add_argument("--lang", choices=["en", "vi"], default="en")
    ap.add_argument("--date-display", default=None,
                    help="date text on cover (default: long date in chosen language)")
    a = ap.parse_args()

    root = Path(a.project_root).resolve()
    day = dt.date.fromisoformat(a.date) if a.date else dt.date.today()
    reports = find_reports_dir(root, a.reports_dir)
    prefix = a.folder_date or day.isoformat()
    target = unique_dir(reports / f"{prefix}_{slugify(a.type)}")
    for sub in ("assets", "figures", "build", "evidence"):
        (target / sub).mkdir(parents=True, exist_ok=True)

    shutil.copy2(TEMPLATES / "progressreport.sty", target / "progressreport.sty")
    body = (TEMPLATES / "report.tex").read_text(encoding="utf-8")
    body = body.replace("%%LANG%%", "vietnamese" if a.lang == "vi" else "english")
    (target / "report.tex").write_text(body, encoding="utf-8")

    notes = []
    logo_tex = ""
    if a.logo:
        logo_tex, note = copy_logo(a.logo, root, target / "assets")
        notes.append(note)

    if a.date_display:
        date_text = a.date_display
    elif a.lang == "vi":
        date_text = f"Ngày {day.day:02d} tháng {day.month:02d} năm {day.year}"
    else:
        date_text = day.strftime("%d %B %Y")

    meta = [
        "% Report metadata -- edit here, not in report.tex.",
        "% Empty fields are omitted from the cover page automatically.",
        f"\\reporttitle{{{tex_escape(a.title)}}}",
        f"\\reportproject{{{tex_escape(a.project)}}}",
        f"\\reportperiod{{{tex_escape(a.period)}}}",
        f"\\reportauthor{{{tex_escape(a.author)}}}",
        f"\\reportrole{{{tex_escape(a.role)}}}",
        f"\\reportorganization{{{tex_escape(a.org)}}}",
        f"\\reportdepartment{{{tex_escape(a.department)}}}",
        f"\\reportsupervisor{{{tex_escape(a.supervisor)}}}",
        f"\\reportrecipient{{{tex_escape(a.recipient)}}}",
        f"\\reportversion{{{tex_escape(a.version)}}}",
        f"\\reportcode{{{tex_escape(a.doc_code)}}}",
        f"\\reportdate{{{tex_escape(date_text)}}}",
        f"\\reportlogo{{{logo_tex}}}",
        "\\reportlogoheight{2.6cm}",
        "",
    ]
    (target / "meta.tex").write_text("\n".join(meta), encoding="utf-8")

    (target / "build" / ".gitignore").write_text("*\n!.gitignore\n", encoding="utf-8")
    readme = f"""# {a.title}{' — ' + a.period if a.period else ''}

- Author: {a.author or '(not set)'}
- Project: {a.project or '(not set)'}
- Date: {day.isoformat()}

## Files
- `report.pdf` — final document for submission
- `report.tex` — report body; `meta.tex` — cover/metadata; `progressreport.sty` — style
- `figures/` — figures used in the report; `assets/` — logo and static assets
- `evidence/` — source scan and evidence ledger (traceability of every figure in the report)
- `build/` — LaTeX intermediate files (safe to delete)

## Rebuild
```
latexmk -xelatex -outdir=build report.tex && cp build/report.pdf report.pdf
```
"""
    (target / "README.md").write_text(readme, encoding="utf-8")

    print(json.dumps({
        "report_dir": str(target),
        "reports_root": str(reports),
        "tex": str(target / "report.tex"),
        "meta": str(target / "meta.tex"),
        "logo": logo_tex or None,
        "notes": notes,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
