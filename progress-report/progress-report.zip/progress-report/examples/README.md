# Example

`weekly-report-example/` is a complete weekly report produced by this workflow for a
small ESP32 demo project (Smart Relay Controller). Use it as a reference for
tone, table layout, the "Status of previous commitments" subsection, the
Evidence column, and the evidence ledger. The logo file is not included; the
names, commits and numbers belong to the demo project only and must never be
reused in a real report.
