#!/usr/bin/env python3
"""Plot a chart from REAL tabular data in the project (CSV/TSV or JSON list of records).

Never type numbers into this script: point it at the source file. Every chart
produced is appended to <report>/evidence/ledger.md with its source, so the
figure is traceable.

  python3 make_chart.py --data path/to/results.csv --x date --y latency_ms [--y p95_ms]
      --kind line|bar|barh|scatter --title "..." --xlabel ... --ylabel ...
      --out <report>/figures/latency.pdf [--filter "col=value"] [--ledger <report>/evidence/ledger.md]

Output format from the extension (.pdf recommended: vector, sharp in LaTeX; .png ok).
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import sys
from pathlib import Path


def load(path: Path) -> list[dict]:
    if path.suffix.lower() == ".json":
        d = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            for v in d.values():
                if isinstance(v, list):
                    d = v
                    break
        if not isinstance(d, list):
            raise SystemExit("JSON must be a list of records (or dict containing one)")
        return d
    delim = "\t" if path.suffix.lower() == ".tsv" else ","
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f, delimiter=delim))


def num(v):
    try:
        return float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--x", required=True)
    ap.add_argument("--y", action="append", required=True)
    ap.add_argument("--kind", default="line", choices=["line", "bar", "barh", "scatter"])
    ap.add_argument("--title", default="")
    ap.add_argument("--xlabel", default=None)
    ap.add_argument("--ylabel", default=None)
    ap.add_argument("--filter", action="append", default=[], help="col=value")
    ap.add_argument("--out", required=True)
    ap.add_argument("--ledger", default=None)
    a = ap.parse_args()

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed: pip install matplotlib (or draw a pgfplots/TikZ chart "
              "that reads the CSV directly)", file=sys.stderr)
        return 2

    src = Path(a.data).resolve()
    rows = load(src)
    for flt in a.filter:
        k, v = flt.split("=", 1)
        rows = [r for r in rows if str(r.get(k)) == v]
    if not rows:
        raise SystemExit("no rows after filtering — nothing to plot")
    missing = [c for c in [a.x, *a.y] if c not in rows[0]]
    if missing:
        raise SystemExit(f"columns not in data: {missing}; available: {list(rows[0].keys())}")

    xs = [r[a.x] for r in rows]
    xnum = [num(x) for x in xs]
    use_num_x = all(v is not None for v in xnum) and a.kind in ("line", "scatter")

    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                         "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150})
    fig, ax = plt.subplots(figsize=(6.2, 3.2))
    palette = ["#1F3A5F", "#B26A00", "#2E7D32", "#C62828", "#6A1B9A", "#00838F"]
    n = len(a.y)
    skipped = 0
    for i, col in enumerate(a.y):
        ys = [num(r[col]) for r in rows]
        skipped += sum(1 for y in ys if y is None)
        pairs = [(x, y) for x, y in zip(xnum if use_num_x else xs, ys) if y is not None]
        px, py = [p[0] for p in pairs], [p[1] for p in pairs]
        c = palette[i % len(palette)]
        if a.kind == "line":
            ax.plot(px, py, marker="o", ms=3, lw=1.5, color=c, label=col)
        elif a.kind == "scatter":
            ax.scatter(px, py, s=12, color=c, label=col)
        elif a.kind in ("bar", "barh"):
            w = 0.8 / n
            pos = [j + (i - (n - 1) / 2) * w for j in range(len(px))]
            (ax.barh if a.kind == "barh" else ax.bar)(pos, py, w, color=c, label=col)
            if a.kind == "bar":
                ax.set_xticks(range(len(px)), px, rotation=30 if len(px) > 6 else 0, ha="right" if len(px) > 6 else "center")
            else:
                ax.set_yticks(range(len(px)), px)
    if use_num_x and all(float(v).is_integer() for v in xnum):
        from matplotlib.ticker import MaxNLocator
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    if a.title:
        ax.set_title(a.title, fontsize=10, loc="left")
    ax.set_xlabel(a.xlabel if a.xlabel is not None else a.x)
    ax.set_ylabel(a.ylabel if a.ylabel is not None else (a.y[0] if n == 1 else ""))
    if n > 1:
        ax.legend(frameon=False)
    fig.tight_layout()
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    md = {"Creator": None} if out.suffix.lower() == ".pdf" else {"Software": None}
    fig.savefig(out, bbox_inches="tight", metadata=md)
    print(f"chart: {out}  rows={len(rows)}  non-numeric values skipped={skipped}")

    ledger = Path(a.ledger) if a.ledger else out.parent.parent / "evidence" / "ledger.md"
    ledger.parent.mkdir(parents=True, exist_ok=True)
    with ledger.open("a", encoding="utf-8") as f:
        try:
            src_txt = str(src.relative_to(Path.cwd()))
        except ValueError:
            src_txt = str(src)
        f.write(f"| Figure `{out.name}`: {', '.join(a.y)} vs {a.x} ({len(rows)} rows"
                f"{', filter ' + '; '.join(a.filter) if a.filter else ''}) | FACT (chart) | "
                f"`{src_txt}` | {dt.date.today().isoformat()} |\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
