#!/usr/bin/env python3
"""Read-only scan of a project to gather progress evidence for a report.

Writes nothing to the project except the --out file (which should be inside
the report folder). Output is a Markdown digest that lists WHERE evidence is;
the agent then reads the relevant files itself.

Usage:
  python3 collect_evidence.py --project-root . [--since YYYY-MM-DD]
      [--until YYYY-MM-DD] [--reports-dir reports] [--out <report>/evidence/scan.md]
      [--json <report>/evidence/scan.json]

--since defaults to the date of the most recent previous report, else 7 days ago.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "env", "__pycache__", "dist",
             "build", ".pio", ".next", "target", ".idea", ".vscode", ".cache",
             ".mypy_cache", ".pytest_cache", "site-packages", ".gradle", "vendor",
             ".tox", "out", "bin", "obj"}
DOC_PATTERNS = re.compile(
    r"(readme|changelog|changes|history|todo|roadmap|progress|status|milestone|"
    r"plan|task|backlog|notes?|report|meeting|minutes|architecture|design|spec|"
    r"requirement|decision|adr|handoff|summary|tien-?do|bao-?cao|ke-?hoach)",
    re.I)
DOC_EXT = {".md", ".markdown", ".txt", ".rst", ".org", ".adoc", ".tex"}
DATA_EXT = {".csv", ".json", ".tsv", ".xlsx", ".log"}
IMG_EXT = {".png", ".jpg", ".jpeg", ".svg", ".pdf", ".gif", ".webp"}
LOGO_RE = re.compile(r"(logo|brand|emblem|seal|crest|insignia|huy-?hieu)", re.I)
BENCH_RE = re.compile(r"(bench|perf|result|metric|measure|profil|latency|throughput)", re.I)
REPORT_DIRS = ["reports", "report", "Reports", "docs/reports", "docs/report",
               "progress-reports", "bao-cao", "baocao"]


def run(cmd: list[str], cwd: Path) -> str:
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=60)
        return r.stdout.strip() if r.returncode == 0 else ""
    except Exception:
        return ""


def walk(root: Path, exclude: set[Path], max_files: int = 20000):
    n = 0
    for dirpath, dirnames, filenames in os.walk(root):
        d = Path(dirpath)
        dirnames[:] = [x for x in dirnames
                       if x not in SKIP_DIRS and (d / x).resolve() not in exclude
                       and not (x.startswith(".") and x not in (".claude", ".github"))]
        for f in filenames:
            n += 1
            if n > max_files:
                return
            yield d / f


def mtime(p: Path) -> str:
    return dt.datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")


def rel(p: Path, root: Path) -> str:
    try:
        return str(p.relative_to(root))
    except ValueError:
        return str(p)


def parse_junit(p: Path) -> dict | None:
    try:
        tree = ET.parse(p)
    except Exception:
        return None
    r = tree.getroot()
    suites = [r] if r.tag == "testsuite" else r.findall("testsuite") if r.tag == "testsuites" else []
    if not suites:
        return None
    tot = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0}
    for s in suites:
        for k in tot:
            try:
                tot[k] += int(float(s.get(k, 0) or 0))
            except ValueError:
                pass
    return tot


def parse_coverage(p: Path) -> str | None:
    try:
        if p.name == "coverage.xml":
            r = ET.parse(p).getroot()
            lr = r.get("line-rate")
            return f"line-rate={float(lr)*100:.1f}%" if lr else None
        if p.name == "coverage-summary.json":
            d = json.loads(p.read_text())
            t = d.get("total", {}).get("lines", {})
            return f"lines={t.get('pct')}%" if t else None
        if p.name == "lcov.info":
            lf = lh = 0
            for line in p.read_text(errors="ignore").splitlines():
                if line.startswith("LF:"):
                    lf += int(line[3:])
                elif line.startswith("LH:"):
                    lh += int(line[3:])
            return f"lines={lh}/{lf} ({lh/lf*100:.1f}%)" if lf else None
    except Exception:
        return None
    return None


def project_name(root: Path) -> list[str]:
    names = []
    try:
        pj = root / "package.json"
        if pj.is_file():
            names.append(f"package.json name: {json.loads(pj.read_text()).get('name')}")
    except Exception:
        pass
    for f, pat in (("pyproject.toml", r'^name\s*=\s*"([^"]+)"'),
                   ("Cargo.toml", r'^name\s*=\s*"([^"]+)"'),
                   ("setup.py", r'name\s*=\s*["\']([^"\']+)'),
                   ("CMakeLists.txt", r'project\s*\(\s*([A-Za-z0-9_\-]+)')):
        p = root / f
        if p.is_file():
            m = re.search(pat, p.read_text(errors="ignore"), re.M)
            if m:
                names.append(f"{f}: {m.group(1)}")
    for rd in ("README.md", "readme.md", "README.MD", "README.rst", "README.txt"):
        p = root / rd
        if p.is_file():
            for line in p.read_text(errors="ignore").splitlines():
                if line.strip().startswith("#"):
                    names.append(f"{rd} heading: {line.strip('# ').strip()}")
                    break
            break
    names.append(f"directory: {root.name}")
    return names


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", default=".")
    ap.add_argument("--reports-dir", default=None)
    ap.add_argument("--exclude-report", default=None,
                    help="the report folder being generated (excluded from the scan)")
    ap.add_argument("--since", default=None)
    ap.add_argument("--until", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--json", default=None)
    a = ap.parse_args()

    root = Path(a.project_root).resolve()
    out: list[str] = []
    data: dict = {"project_root": str(root)}

    # ---- reports dir & previous reports
    reports_dir = None
    if a.reports_dir:
        reports_dir = (root / a.reports_dir).resolve()
    else:
        for c in REPORT_DIRS:
            if (root / c).is_dir():
                reports_dir = (root / c).resolve()
                break
    exclude = set()
    current = Path(a.exclude_report).resolve() if a.exclude_report else None
    prev = []
    if reports_dir and reports_dir.is_dir():
        for d in sorted(reports_dir.iterdir()):
            if d.is_dir() and (current is None or d.resolve() != current):
                m = re.match(r"(\d{4}-\d{2}(?:-\d{2})?)", d.name)
                prev.append({"dir": rel(d, root), "date": m.group(1) if m else None,
                             "tex": [rel(x, root) for x in d.glob("*.tex")],
                             "pdf": [rel(x, root) for x in d.glob("*.pdf")],
                             "ledger": rel(d / "evidence" / "ledger.md", root)
                             if (d / "evidence" / "ledger.md").is_file() else None})
        exclude.add(reports_dir)
    data["previous_reports"] = prev

    # ---- period
    today = dt.date.today()
    since = a.since
    if not since:
        dated = [p["date"] for p in prev if p["date"] and len(p["date"]) == 10]
        since = max(dated) if dated else (today - dt.timedelta(days=7)).isoformat()
    until = a.until or today.isoformat()
    data["period"] = {"since": since, "until": until}

    out.append(f"# Evidence scan: {root.name}")
    out.append(f"Scan date: {today.isoformat()}  |  Period considered: {since} → {until}")
    out.append("Paths are relative to the project root. This is an index; open the files to read content.\n")

    out.append("## Project identity candidates")
    names = project_name(root)
    data["project_name_candidates"] = names
    out += [f"- {n}" for n in names]

    # ---- git
    out.append("\n## Git")
    is_git = run(["git", "rev-parse", "--is-inside-work-tree"], root) == "true"
    data["git"] = {"is_repo": is_git}
    if is_git:
        g = data["git"]
        g["branch"] = run(["git", "rev-parse", "--abbrev-ref", "HEAD"], root)
        g["head"] = run(["git", "log", "-1", "--format=%h %ad %s", "--date=short"], root)
        g["total_commits"] = run(["git", "rev-list", "--count", "HEAD"], root)
        g["first_commit"] = run(["git", "log", "--reverse", "--format=%ad", "--date=short"], root).split("\n")[0]
        g["user_name"] = run(["git", "config", "user.name"], root)
        g["authors_all"] = run(["git", "shortlog", "-sne", "HEAD"], root)
        rng = ["--since", f"{since} 00:00", "--until", f"{until} 23:59"]
        g["commits_in_period"] = run(["git", "log", *rng, "--format=%h|%ad|%an|%s", "--date=short"], root)
        g["commit_count_in_period"] = len([l for l in g["commits_in_period"].splitlines() if l])
        g["diffstat_in_period"] = run(["git", "log", *rng, "--shortstat", "--format="], root)
        ins = sum(int(x) for x in re.findall(r"(\d+) insertion", g["diffstat_in_period"]))
        dele = sum(int(x) for x in re.findall(r"(\d+) deletion", g["diffstat_in_period"]))
        g["lines_added_in_period"], g["lines_deleted_in_period"] = ins, dele
        g["files_touched_in_period"] = run(
            ["git", "log", *rng, "--name-only", "--format="], root)
        files_touched = sorted(set(x for x in g["files_touched_in_period"].splitlines() if x))
        g["tags"] = run(["git", "tag", "--sort=-creatordate", "--format=%(refname:short) %(creatordate:short)"], root)
        rep_rel = rel(reports_dir, root) if reports_dir else None
        g["status_short"] = "\n".join(
            l for l in run(["git", "status", "--short"], root).splitlines()
            if not (rep_rel and l[3:].startswith(rep_rel)))
        out.append(f"- Branch: `{g['branch']}` | HEAD: {g['head']}")
        out.append(f"- Total commits: {g['total_commits']} | first commit: {g['first_commit']}")
        out.append(f"- git user.name (author candidate): {g['user_name'] or '(unset)'}")
        out.append(f"- Commits in period: **{g['commit_count_in_period']}** "
                   f"(+{ins} / -{dele} lines, {len(files_touched)} files) "
                   f"— source: `git log --since {since} --until {until}`")
        if g["commits_in_period"]:
            out.append("\n```\n" + "\n".join(g["commits_in_period"].splitlines()[:150]) + "\n```")
        if files_touched:
            out.append("\nFiles touched in period (first 80):")
            out += [f"- {f}" for f in files_touched[:80]]
        if g["tags"]:
            out.append("\nTags (latest 10):\n```\n" + "\n".join(g["tags"].splitlines()[:10]) + "\n```")
        if g["status_short"]:
            out.append("\nUncommitted changes (work in progress signal):\n```\n"
                       + "\n".join(g["status_short"].splitlines()[:40]) + "\n```")
    else:
        out.append("- Not a git repository (no commit evidence available).")

    # ---- task state (task-progress / project-workflow)
    out.append("\n## Task / progress state files")
    task_hits = []
    ts = root / ".claude" / "task-state"
    if ts.is_dir():
        out.append("- task-progress state root found: `.claude/task-state/` "
                   "(read active-tasks.md, task-index.md, then per task: CURRENT_STATE, PROGRESS, "
                   "BLOCKERS, TESTS, DECISIONS, NEXT_STEPS, SESSION_HANDOFF)")
        for f in ("task-index.md", "active-tasks.md"):
            if (ts / f).is_file():
                task_hits.append(rel(ts / f, root))
        for td in sorted(ts.glob("TASK-*")):
            if td.is_dir():
                header = {}
                tm = td / "TASK.md"
                if tm.is_file():
                    for line in tm.read_text(errors="ignore").splitlines()[:30]:
                        m = re.match(r"^\s*[-*]?\s*\**(Task ID|Task Name|Status|Created|Last Updated)\**\s*:\s*(.+)", line)
                        if m:
                            header[m.group(1)] = m.group(2).strip()
                out.append(f"  - `{rel(td, root)}` — {header.get('Task Name','?')} | "
                           f"Status: {header.get('Status','?')} | Updated: {header.get('Last Updated','?')}")
                task_hits.append(rel(td, root))
    for d in ("tasks/active", "tasks/completed", "tasks"):
        p = root / d
        if p.is_dir():
            files = sorted(x for x in p.glob("*.md"))
            if files:
                out.append(f"- `{d}/`: " + ", ".join(f"`{x.name}`" for x in files[:30]))
                task_hits += [rel(x, root) for x in files]
    for f in ("docs/project-context.md", "docs/progress.md", "PROGRESS.md", "STATUS.md", "TODO.md"):
        if (root / f).is_file():
            task_hits.append(f)
            out.append(f"- `{f}` (modified {mtime(root / f)})")
    if not task_hits:
        out.append("- None found.")
    data["task_state"] = task_hits

    # ---- walk files
    docs, images, logos, tests, cov, bench, data_files, jira = [], [], [], [], [], [], [], []
    for p in walk(root, exclude):
        name = p.name.lower()
        ext = p.suffix.lower()
        r = rel(p, root)
        if ext in DOC_EXT and (DOC_PATTERNS.search(name) or "/docs/" in f"/{r}" or r.startswith("docs")):
            docs.append((r, mtime(p), p.stat().st_size))
        if ext in IMG_EXT:
            if LOGO_RE.search(name) or LOGO_RE.search(p.parent.name):
                logos.append((r, mtime(p)))
            elif ext != ".pdf" or any(k in r.lower() for k in ("fig", "diagram", "img", "image", "screenshot", "asset")):
                images.append((r, mtime(p)))
        if ext == ".xml" and ("junit" in name or "test" in name or "result" in name):
            j = parse_junit(p)
            if j:
                tests.append((r, mtime(p), j))
        if name in ("coverage.xml", "coverage-summary.json", "lcov.info"):
            c = parse_coverage(p)
            cov.append((r, mtime(p), c))
        if ext in DATA_EXT and BENCH_RE.search(name):
            bench.append((r, mtime(p)))
        elif ext in (".csv", ".json") and "jira" in name:
            jira.append((r, mtime(p)))
        elif ext in (".csv", ".tsv") and len(data_files) < 60:
            data_files.append((r, mtime(p)))

    def section(title, rows, fmt):
        out.append(f"\n## {title}")
        if not rows:
            out.append("- None found.")
        for row in rows:
            out.append(fmt(row))

    docs.sort(key=lambda x: x[1], reverse=True)
    section("Documentation / notes (newest first)", docs[:80],
            lambda x: f"- `{x[0]}` — modified {x[1]}, {x[2]} bytes")
    section("Test results (JUnit XML)", tests,
            lambda x: f"- `{x[0]}` ({x[1]}): tests={x[2]['tests']}, failures={x[2]['failures']}, "
                      f"errors={x[2]['errors']}, skipped={x[2]['skipped']}")
    section("Coverage reports", cov, lambda x: f"- `{x[0]}` ({x[1]}): {x[2] or 'unparsed'}")
    section("Benchmark / measurement files", bench[:40], lambda x: f"- `{x[0]}` ({x[1]})")
    section("Jira / tracker exports", jira, lambda x: f"- `{x[0]}` ({x[1]})")
    section("Other tabular data (possible chart sources)", data_files[:40], lambda x: f"- `{x[0]}` ({x[1]})")
    section("Logo candidates", logos, lambda x: f"- `{x[0]}` ({x[1]})")
    images.sort(key=lambda x: x[1], reverse=True)
    section("Images / diagrams (newest first, max 60)", images[:60], lambda x: f"- `{x[0]}` ({x[1]})")

    out.append("\n## Previous reports")
    if prev:
        for p in prev[-5:]:
            out.append(f"- `{p['dir']}` date={p['date']} tex={p['tex']} pdf={p['pdf']}"
                       + (f" ledger=`{p['ledger']}`" if p['ledger'] else ""))
        out.append(f"\nMost recent: `{prev[-1]['dir']}` — read its report.tex sections "
                   "'Next Steps', 'Work in Progress', 'Issues' to check commitments.")
    else:
        out.append("- None found (first report).")

    data.update({"docs": docs, "tests": tests, "coverage": cov, "bench": bench,
                 "jira": jira, "logos": logos, "images": images[:60]})
    text = "\n".join(out) + "\n"
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(text, encoding="utf-8")
    if a.json:
        Path(a.json).parent.mkdir(parents=True, exist_ok=True)
        Path(a.json).write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
