#!/usr/bin/env bash
# Compile a progress report folder to PDF.
#   bash compile_report.sh <report_dir> [--engine xelatex|lualatex|pdflatex] [--submit-name NAME.pdf]
# Intermediate files go to <report_dir>/build/. Final PDF: <report_dir>/report.pdf
# Exit codes: 0 ok, 1 LaTeX error (see printed excerpt), 2 missing toolchain.
set -uo pipefail

DIR="${1:-.}"; shift || true
ENGINE="${ENGINE:-}"
SUBMIT_NAME=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --engine) ENGINE="$2"; shift 2;;
    --submit-name) SUBMIT_NAME="$2"; shift 2;;
    *) echo "unknown option $1"; exit 2;;
  esac
done

cd "$DIR" || { echo "report dir not found: $DIR"; exit 2; }
TEX="report.tex"
[[ -f "$TEX" ]] || { echo "report.tex not found in $(pwd)"; exit 2; }
mkdir -p build

# Engine: Unicode engines first (Vietnamese and other diacritics just work).
if [[ -z "$ENGINE" ]]; then
  for e in xelatex lualatex pdflatex; do
    if command -v "$e" >/dev/null 2>&1; then ENGINE="$e"; break; fi
  done
fi
if [[ -z "$ENGINE" ]] || ! command -v "$ENGINE" >/dev/null 2>&1; then
  echo "ERROR: no LaTeX engine found (need xelatex, lualatex or pdflatex)."
  echo "Install e.g.: sudo apt install texlive-xetex texlive-latex-extra texlive-fonts-recommended latexmk"
  echo "           or: brew install --cask mactex-no-gui"
  exit 2
fi
if [[ "$ENGINE" == "pdflatex" ]] && LC_ALL=C grep -qP '[^\x00-\x7F]' "$TEX" meta.tex 2>/dev/null; then
  echo "WARNING: non-ASCII text with pdflatex; Vietnamese needs the vntex package (T5)."
fi
echo "Engine: $ENGINE"

FLAGS=(-interaction=nonstopmode -halt-on-error -file-line-error)
STATUS=0
if command -v latexmk >/dev/null 2>&1; then
  case "$ENGINE" in
    xelatex)  MK=(-xelatex);;
    lualatex) MK=(-lualatex);;
    *)        MK=(-pdf);;
  esac
  latexmk "${MK[@]}" "${FLAGS[@]}" -outdir=build -auxdir=build "$TEX" >build/latexmk.out 2>&1 || STATUS=$?
else
  # manual passes: 3 runs resolve TOC, LastPage and cross-references
  for i in 1 2 3; do
    "$ENGINE" "${FLAGS[@]}" -output-directory=build "$TEX" >build/pass$i.out 2>&1 || { STATUS=$?; break; }
    if [[ $i -ge 2 ]] && ! grep -q "Rerun to get\|Label(s) may have changed" build/report.log; then break; fi
  done
fi

LOG=build/report.log
if [[ $STATUS -ne 0 || ! -f build/report.pdf ]]; then
  echo "BUILD FAILED (exit $STATUS). Error excerpt from $LOG:"
  if [[ -f $LOG ]]; then
    grep -n -A4 -E '^!|^\./.*:[0-9]+:|^.*\.tex:[0-9]+:|Emergency stop|Fatal error' "$LOG" | head -60
    grep -n -E 'File `[^'"'"']+'"'"' not found|LaTeX Error: File' "$LOG" | head -10
  else
    tail -40 build/*.out 2>/dev/null
  fi
  exit 1
fi

cp build/report.pdf report.pdf
[[ -n "$SUBMIT_NAME" ]] && cp report.pdf "$SUBMIT_NAME" && echo "Submit copy: $(pwd)/$SUBMIT_NAME"

echo "BUILD OK: $(pwd)/report.pdf"
# concise warning summary
UNDEF=$(grep -c "undefined" "$LOG" || true)
OVERFULL=$(grep -c "Overfull \\\\hbox" "$LOG" || true)
MISSINGCH=$(grep -c "Missing character" "$LOG" || true)
echo "Warnings: undefined-refs=$UNDEF overfull-hbox=$OVERFULL missing-glyphs=$MISSINGCH"
grep -E "Overfull \\\\hbox \(([2-9][0-9]|[1-9][0-9]{2,})\.[0-9]+pt" "$LOG" | head -10
grep "Missing character" "$LOG" | sort | uniq | head -10
exit 0
