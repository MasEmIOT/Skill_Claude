#!/usr/bin/env python3
"""Quality gate for a compiled progress report.

  python3 check_pdf.py <report_dir> [--expect "Executive Summary,Next Steps"]
                       [--allow-term Claude] [--dpi 70] [--no-render]

Checks: PDF exists/opens, page count, metadata, expected headings, leftover
placeholders / "??" references, AI-attribution wording (text + metadata +
.tex sources), LaTeX log problems (overfull boxes, missing glyphs, missing
files, undefined refs), logo/images present, and renders preview PNGs of
the cover, last page and pages that carry tables/figures into build/preview/.

Exit 0 = no errors (warnings may exist), 1 = errors found, 2 = no PDF.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

# Strong: unambiguous AI attribution -> error.
AI_PATTERNS = [
    r"\bclaude\b", r"\banthropic\b", r"\bchat\s?gpt\b",
    r"created\s+(by|with|using)\s+(an?\s+)?(ai|claude|llm|assistant)",
    r"prepared\s+(by|with)\s+(an?\s+)?(ai|claude|llm|assistant)",
    r"generated\s+(by|with|using)\s+(an?\s+)?(ai|claude|llm|assistant|chatgpt)",
    r"\bas an ai\b", r"\bai[- ]assistant\b", r"\bai[- ]generated\b",
    r"\bmy analysis as\b", r"được tạo bởi\s+(ai|claude)",
]
# Weak: may be legitimate project content -> warning, review in context.
AI_WEAK_PATTERNS = [
    r"\bopenai\b", r"\bgpt-?\d", r"\bgemini\b", r"\bcopilot\b",
    r"\blanguage model\b", r"\bllm\b", r"\bgenerated\s+(by|with|using)\b",
]
DEFAULT_EXPECT = {
    "en": ["Executive Summary", "Work Completed", "Next Steps", "Conclusion"],
    "vi": ["Tóm tắt", "Kết luận"],
}


def sh(cmd: list[str]) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return r.returncode, r.stdout + r.stderr
    except FileNotFoundError:
        return 127, f"{cmd[0]} not installed"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("report_dir")
    ap.add_argument("--expect", default=None, help="comma-separated headings that must appear")
    ap.add_argument("--allow-term", action="append", default=[],
                    help="term that is legitimately part of the project (e.g. the project is about Claude)")
    ap.add_argument("--dpi", type=int, default=70)
    ap.add_argument("--no-render", action="store_true")
    a = ap.parse_args()

    d = Path(a.report_dir).resolve()
    pdf = d / "report.pdf"
    errors, warnings, info = [], [], []
    if not pdf.is_file():
        print(json.dumps({"ok": False, "errors": [f"missing {pdf}"]}, indent=2))
        return 2

    # ---- open / metadata
    rc, meta_out = sh(["pdfinfo", str(pdf)])
    meta = {}
    if rc == 0:
        for line in meta_out.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()
    elif rc == 127:
        warnings.append("pdfinfo not available (install poppler-utils) — limited checks")
    else:
        errors.append(f"PDF cannot be opened: {meta_out.strip()[:200]}")
    pages = int(meta.get("Pages", "0") or 0)
    info.append(f"pages={pages} size={meta.get('Page size','?')}")
    info.append(f"metadata Title='{meta.get('Title','')}' Author='{meta.get('Author','')}' "
                f"Creator='{meta.get('Creator','')}' Producer='{meta.get('Producer','')}'")
    if not meta.get("Author"):
        warnings.append("PDF metadata has no Author (check \\reportauthor in meta.tex)")

    allow = [t.lower() for t in a.allow_term]

    def ai_hits(text: str, patterns=None) -> list[str]:
        hits = []
        for pat in patterns or AI_PATTERNS:
            for m in re.finditer(pat, text, re.I):
                word = m.group(0).lower()
                if any(t in word or word in t for t in allow):
                    continue
                s = max(0, m.start() - 50)
                hits.append(re.sub(r"\s+", " ", text[s:m.end() + 50]))
        return hits

    for k, v in meta.items():
        for h in ai_hits(v):
            errors.append(f"AI attribution in PDF metadata {k}: '{h}'")

    # ---- text
    rc, _ = sh(["pdftotext", "-layout", str(pdf), str(d / "build" / "report.txt")])
    text = ""
    page_texts: list[str] = []
    if rc == 0:
        text = (d / "build" / "report.txt").read_text(errors="ignore")
        page_texts = text.split("\f")
    else:
        warnings.append("pdftotext not available — text checks skipped")

    if text:
        if len(text.strip()) < 200:
            errors.append("PDF contains almost no extractable text (font/render problem?)")
        lang = "vi" if re.search(r"\\usepackage\[vietnamese\]", (d / "report.tex").read_text(errors="ignore")) else "en"
        expect = [e.strip() for e in a.expect.split(",")] if a.expect else DEFAULT_EXPECT[lang]
        norm = re.sub(r"\s+", " ", text).lower()
        for h in expect:
            if h.lower() not in norm:
                errors.append(f"expected heading not found in PDF text: '{h}'")
        if "[[" in text:
            for m in re.finditer(r"\[\[[^\]]{0,80}\]\]", text):
                errors.append(f"unfilled placeholder in PDF: {m.group(0)}")
        if re.search(r"(?<![\w?])\?\?(?![\w?])", text):
            errors.append("'??' found in PDF — unresolved \\ref / \\cite (recompile or fix label)")
        for h in ai_hits(text):
            errors.append(f"AI-attribution-like wording in PDF text: '...{h}...'")
        for h in ai_hits(text, AI_WEAK_PATTERNS)[:10]:
            warnings.append(f"review wording (AI-related term, OK only if it is project content): '...{h}...'")

    # ---- tex sources
    for tf in list(d.glob("*.tex")):
        src = tf.read_text(errors="ignore")
        body = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("%"))
        if "\\placeholder{" in body and tf.name == "report.tex":
            n = body.count("\\placeholder{")
            errors.append(f"{tf.name}: {n} \\placeholder{{}} macro(s) still present")
        for h in ai_hits(body):
            errors.append(f"AI-attribution-like wording in {tf.name}: '...{h}...'")

    # ---- log
    log = d / "build" / "report.log"
    if log.is_file():
        L = log.read_text(errors="ignore")
        big_overfull = re.findall(r"Overfull \\hbox \((\d+\.\d+)pt too wide\)[^\n]*lines? (\d+)", L)
        bad = [(float(w), ln) for w, ln in big_overfull if float(w) > 3.0]
        if bad:
            worst = sorted(bad, reverse=True)[:8]
            warnings.append("overfull hbox >3pt (text/table sticking into margin) at report.tex lines: "
                            + ", ".join(f"{ln} ({w:.0f}pt)" for w, ln in worst))
        vbad = re.findall(r"Overfull \\vbox \((\d+\.\d+)pt too high\)", L)
        if any(float(x) > 5 for x in vbad):
            warnings.append(f"overfull vbox (content taller than page/float) x{len(vbad)}")
        miss = sorted(set(re.findall(r"Missing character: There is no (\S+)", L)))
        if miss:
            errors.append("missing glyphs in font (characters dropped from PDF): " + " ".join(miss[:20]))
        for m in re.findall(r"File `([^']+)' not found", L):
            errors.append(f"missing file referenced in LaTeX: {m}")
        if re.search(r"Logo file '([^']+)' not found", L):
            errors.append("logo file declared in meta.tex was not found")
        undef = sorted(set(re.findall(r"Reference `([^']+)' on page \d+ undefined", L)))
        if undef:
            errors.append("undefined references: " + ", ".join(undef))
        if "Rerun to get" in L or "Label(s) may have changed" in L:
            warnings.append("LaTeX asks for another run (TOC/refs may be stale) — recompile")
    else:
        warnings.append("build/report.log not found — log checks skipped")

    # ---- images / logo
    meta_tex = (d / "meta.tex").read_text(errors="ignore") if (d / "meta.tex").is_file() else ""
    m = re.search(r"\\reportlogo\{([^}]*)\}", meta_tex)
    logo = m.group(1).strip() if m else ""
    rc, imgs = sh(["pdfimages", "-list", str(pdf)])
    img_pages: set[int] = set()
    if rc == 0:
        for line in imgs.splitlines()[2:]:
            parts = line.split()
            if parts and parts[0].isdigit():
                img_pages.add(int(parts[0]))
        info.append(f"raster images on pages: {sorted(img_pages) or 'none'}")
    if logo:
        if not (d / logo).is_file():
            errors.append(f"logo path in meta.tex does not exist: {logo}")
        elif logo.lower().endswith((".png", ".jpg", ".jpeg")) and rc == 0 and 1 not in img_pages:
            errors.append("raster logo configured but no image found on page 1")
        else:
            info.append(f"logo: {logo} (verify visually on cover preview)")
    else:
        info.append("no logo configured")

    # ---- which pages to preview
    table_pages, fig_pages = set(), set()
    for i, pt in enumerate(page_texts, 1):
        if re.search(r"^\s*(Table|Bảng)\s+\d+[.:]", pt, re.M):
            table_pages.add(i)
        if re.search(r"^\s*(Figure|Hình)\s+\d+[.:]", pt, re.M):
            fig_pages.add(i)
    preview = sorted({1, max(pages, 1)} | set(list(sorted(table_pages))[:3])
                     | set(list(sorted(fig_pages))[:3]) | set(list(sorted(img_pages - {1}))[:2]))
    preview = [p for p in preview if 1 <= p <= max(pages, 1)]
    rendered = []
    if not a.no_render and shutil.which("pdftoppm"):
        pv = d / "build" / "preview"
        pv.mkdir(parents=True, exist_ok=True)
        for old in pv.glob("*.png"):
            old.unlink()
        for p in preview:
            sh(["pdftoppm", "-f", str(p), "-l", str(p), "-r", str(a.dpi), "-png",
                "-singlefile", str(pdf), str(pv / f"page-{p:02d}")])
        rendered = sorted(str(x) for x in pv.glob("*.png"))
    elif not a.no_render:
        warnings.append("pdftoppm not available — no visual previews; inspect PDF manually")

    result = {
        "ok": not errors, "pdf": str(pdf), "pages": pages,
        "table_pages": sorted(table_pages), "figure_pages": sorted(fig_pages),
        "errors": errors, "warnings": warnings, "info": info,
        "previews_to_inspect": rendered,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
