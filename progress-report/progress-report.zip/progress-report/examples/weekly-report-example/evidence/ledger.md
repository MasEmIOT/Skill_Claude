# Evidence ledger — 2026-09-29_weekly-progress

| Claim in report | Type | Source | Checked |
|---|---|---|---|
| 6 commits in period | FACT | `git log --since 2026-09-22 --until 2026-09-29` | 2026-09-29 |
| 27 tests: 24 pass, 2 fail, 1 skipped | FACT | `test-results/junit.xml` | 2026-09-29 |
| 2 of 4 acceptance criteria met (50%) | DERIVED | `.claude/task-state/TASK-20260915-001_relay-control/TASK.md` | 2026-09-29 |
| Weekday-range parsing blocked | FACT | `BLOCKERS.md` B-001 | 2026-09-29 |
| Brown-out fix on relay 3 | FACT | commit 9b8605b | 2026-09-29 |
| Figure `mqtt_latency.pdf`: p50_ms, p95_ms vs run (5 rows) | FACT (chart) | `bench/mqtt_latency.csv` | 2026-09-29 |
