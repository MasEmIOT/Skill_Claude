# Writing guide — sounding like the engineer who did the work

The report is written in the voice of the author (the user). It is a working
document for a manager or supervisor: short, specific, verifiable.

## 1. Voice

- EN: first person singular or neutral passive, consistently. "I implemented…"
  or "The relay driver was implemented…". Pick one per report. Team projects:
  "we" only if the user said it is a team.
- VI: "Em/Tôi đã…" only if the user uses that form; default to neutral:
  "Đã hoàn thành…", "Module X được triển khai…".
- Past tense for done work, present for status, future ("will") for plans.

## 2. Be concrete

| Weak (avoid) | Strong (use) |
|---|---|
| Significant progress was made on the backend. | The REST API now covers 6 of the 8 planned endpoints (`/devices`, `/schedules`, …). |
| Improved performance. | Median response time dropped from 420 ms to 180 ms (bench/api_latency.csv). |
| Faced some challenges with hardware. | The ESP32 resets when the relay switches (brown-out); observed 5 times in the serial log of 27/09. |
| Testing is ongoing. | 18 of 24 integration tests pass; the 6 failures are all in the scheduler module. |

Each completed item answers: what was done, what it enables, how it is proven.

## 3. Words and patterns to avoid

They make text read as machine-written or as filler:

- delve, leverage, seamless, robust (without evidence), cutting-edge,
  state-of-the-art, comprehensive, crucial, pivotal, showcase, underscore,
  boasts, meticulous, harness, realm, landscape, tapestry, journey, testament
- "It is worth noting that", "It is important to note", "In today's fast-paced…"
- "not only X but also Y" as a habit; groups of three adjectives
- Rhetorical questions, exclamation marks, emojis
- Summary sentences that restate the paragraph ("Overall, this demonstrates…")
- Em-dash chains; use commas, colons or separate sentences
- Bold on random phrases inside paragraphs
- Any reference to AI, Claude, assistants, "generated", "this report was produced by"

## 4. Section guidance

- **Executive Summary** (4–8 sentences): overall status in one line; 2–3 main
  results with numbers; main issue; next milestone with target date if known.
- **Project Overview**: stable context. Reuse and tighten the previous report's
  overview if one exists; do not rewrite it every week.
- **Progress Overview**: table by work area + "Status of previous commitments"
  when a previous report exists.
- **Work Completed**: grouped by area; table with an Evidence column
  (commit hash, test ID, file). Short prose under the table only for items
  that need explanation.
- **Work in Progress**: what, current state, what remains, expected completion
  only if the user/project states it.
- **Results**: numbers, tables, charts, screenshots. Each figure gets a caption
  that states what it shows and its source.
- **Issues**: symptom, impact, cause (fact or clearly-labelled assessment).
- **Solutions**: one per issue, marked Done / In progress / Proposed.
- **Next Steps**: specific, ordered, ideally with owner/date if known.
- **Risks**: only real ones with a basis (blocked dependency, failing test,
  missing hardware). Omit the section if there are none.
- **Conclusion**: 3–5 sentences; no new information.

## 5. Length

Weekly: 4–8 pages including cover. Monthly/technical: 8–15. Remove the TOC for
reports under ~5 pages. Remove empty sections rather than padding them.

## 6. Language

Follow the user's choice (`lang=`). If unspecified: the language of the
project docs; if mixed, English. Keep technical terms (API, firmware, commit)
untranslated in Vietnamese reports when that is how the team writes.
